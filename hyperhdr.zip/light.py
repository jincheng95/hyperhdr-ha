"""Support for HyperHDR remotes."""
from __future__ import annotations

from collections.abc import Callable, Mapping, Sequence
import functools
import logging
from types import MappingProxyType
from typing import Any

from hyperhdr import client, const

from homeassistant.components.light import (
    ATTR_BRIGHTNESS,
    ATTR_EFFECT,
    ATTR_HS_COLOR,
    ColorMode,
    LightEntity,
    LightEntityFeature,
)
from homeassistant.config_entries import ConfigEntry
from homeassistant.core import HomeAssistant, callback
from homeassistant.helpers.device_registry import DeviceInfo
from homeassistant.helpers.dispatcher import (
    async_dispatcher_connect,
    async_dispatcher_send,
)
from homeassistant.helpers.entity_platform import AddEntitiesCallback
import homeassistant.util.color as color_util

from . import (
    get_hyperhdr_device_id,
    get_hyperhdr_unique_id,
    listen_for_instance_updates,
)
from .const import (
    CONF_CLEAR_PRIORITY_ON_TURN_OFF,
    CONF_EFFECT_HIDE_LIST,
    CONF_INSTANCE_CLIENTS,
    CONF_KEEP_REALTIME_ON_TURN_OFF,
    CONF_PRIORITY,
    DEFAULT_CLEAR_PRIORITY_ON_TURN_OFF,
    DEFAULT_KEEP_REALTIME_ON_TURN_OFF,
    DEFAULT_ORIGIN,
    DEFAULT_PRIORITY,
    DOMAIN,
    HYPERHDR_MANUFACTURER_NAME,
    HYPERHDR_MODEL_NAME,
    NAME_SUFFIX_HYPERHDR_LIGHT,
    NAME_SUFFIX_HYPERHDR_PRIORITY_LIGHT,
    SIGNAL_ENTITY_REMOVE,
    TYPE_HYPERHDR_LIGHT,
    TYPE_HYPERHDR_PRIORITY_LIGHT,
)

_LOGGER = logging.getLogger(__name__)

COLOR_BLACK = color_util.COLORS["black"]

CONF_DEFAULT_COLOR = "default_color"
CONF_HDMI_PRIORITY = "hdmi_priority"
CONF_EFFECT_LIST = "effect_list"

# As we want to preserve brightness control for effects (e.g. to reduce the
# brightness for VIDEOGRABBER), we need to persist the effect that is in flight, so
# subsequent calls to turn_on will know the keep the effect enabled.
# Unfortunately the Home Assistant UI does not easily expose a way to remove a
# selected effect (there is no 'No Effect' option by default). Instead, we
# create a new fake effect ("Solid") that is always selected by default for
# showing a solid color. This is the same method used by WLED.
KEY_EFFECT_SOLID = "Solid"

DEFAULT_COLOR = [255, 255, 255]
DEFAULT_BRIGHTNESS = 255
DEFAULT_EFFECT = KEY_EFFECT_SOLID
DEFAULT_NAME = "HyperHDR"
DEFAULT_PORT = const.DEFAULT_PORT_JSON
DEFAULT_HDMI_PRIORITY = 880
DEFAULT_EFFECT_LIST: list[str] = []

ICON_LIGHTBULB = "mdi:lightbulb"
ICON_EFFECT = "mdi:lava-lamp"
ICON_EXTERNAL_SOURCE = "mdi:television-ambient-light"


async def async_setup_entry(
    hass: HomeAssistant,
    config_entry: ConfigEntry,
    async_add_entities: AddEntitiesCallback,
) -> None:
    """Set up a HyperHDR platform from config entry."""

    entry_data = hass.data[DOMAIN][config_entry.entry_id]
    server_id = config_entry.unique_id

    @callback
    def instance_add(instance_num: int, instance_name: str, sysinfo: dict[str, Any]) -> None:
        """Add entities for a new HyperHDR instance."""
        assert server_id
        args = (
            server_id,
            instance_num,
            instance_name,
            config_entry.options,
            entry_data[CONF_INSTANCE_CLIENTS][instance_num],
        )
        async_add_entities(
            [
                HyperHDRLight(*args),
                HyperHDRPriorityLight(*args),
            ]
        )

    @callback
    def instance_remove(instance_num: int) -> None:
        """Remove entities for an old HyperHDR instance."""
        assert server_id
        for light_type in LIGHT_TYPES:
            async_dispatcher_send(
                hass,
                SIGNAL_ENTITY_REMOVE.format(
                    get_hyperhdr_unique_id(server_id, instance_num, light_type)
                ),
            )

    listen_for_instance_updates(hass, config_entry, instance_add, instance_remove)


class HyperHDRBaseLight(LightEntity):
    """A HyperHDR light base class."""

    _attr_color_mode = ColorMode.HS
    _attr_supported_color_modes = {ColorMode.HS}
    _attr_supported_features = LightEntityFeature.EFFECT

    def __init__(
        self,
        server_id: str,
        instance_num: int,
        instance_name: str,
        options: MappingProxyType[str, Any],
        hyperhdr_client: client.HyperHDRClient,
    ) -> None:
        """Initialize the light."""
        self._unique_id = self._compute_unique_id(server_id, instance_num)
        self._name = self._compute_name(instance_name)
        self._device_id = get_hyperhdr_device_id(server_id, instance_num)
        self._instance_name = instance_name
        self._options = options
        self._client = hyperhdr_client

        # Active state representing the HyperHDR instance.
        self._brightness: int = 255
        self._rgb_color: Sequence[int] = DEFAULT_COLOR
        self._effect: str = KEY_EFFECT_SOLID

        self._static_effect_list: list[str] = [KEY_EFFECT_SOLID]
        if self._support_external_effects:
            self._static_effect_list += [
                const.KEY_COMPONENTID_TO_NAME[component]
                for component in const.KEY_COMPONENTID_EXTERNAL_SOURCES
            ]
        self._effect_list: list[str] = self._static_effect_list[:]

        self._client_callbacks: Mapping[str, Callable[[dict[str, Any]], None]] = {
            f"{const.KEY_ADJUSTMENT}-{const.KEY_UPDATE}": self._update_adjustment,
            f"{const.KEY_COMPONENTS}-{const.KEY_UPDATE}": self._update_components,
            f"{const.KEY_EFFECTS}-{const.KEY_UPDATE}": self._update_effect_list,
            f"{const.KEY_PRIORITIES}-{const.KEY_UPDATE}": self._update_priorities,
            f"{const.KEY_CLIENT}-{const.KEY_UPDATE}": self._update_client,
        }

    def _compute_unique_id(self, server_id: str, instance_num: int) -> str:
        """Compute a unique id for this instance."""
        raise NotImplementedError

    def _compute_name(self, instance_name: str) -> str:
        """Compute the name of the light."""
        raise NotImplementedError

    @property
    def entity_registry_enabled_default(self) -> bool:
        """Whether or not the entity is enabled by default."""
        return True

    @property
    def should_poll(self) -> bool:
        """Return whether or not this entity should be polled."""
        return False

    @property
    def name(self) -> str:
        """Return the name of the light."""
        return self._name

    @property
    def brightness(self) -> int:
        """Return the brightness of this light between 0..255."""
        return self._brightness

    @property
    def hs_color(self) -> tuple[float, float]:
        """Return last color value set."""
        return color_util.color_RGB_to_hs(*self._rgb_color)

    @property
    def icon(self) -> str:
        """Return state specific icon."""
        if self.is_on:
            if (
                self.effect in const.KEY_COMPONENTID_FROM_NAME
                and const.KEY_COMPONENTID_FROM_NAME[self.effect]
                in const.KEY_COMPONENTID_EXTERNAL_SOURCES
            ):
                return ICON_EXTERNAL_SOURCE
            if self.effect != KEY_EFFECT_SOLID:
                return ICON_EFFECT
        return ICON_LIGHTBULB

    @property
    def effect(self) -> str:
        """Return the current effect."""
        return self._effect

    @property
    def effect_list(self) -> list[str]:
        """Return the list of supported effects."""
        return self._effect_list

    @property
    def available(self) -> bool:
        """Return server availability."""
        return bool(self._client.has_loaded_state)

    @property
    def unique_id(self) -> str:
        """Return a unique id for this instance."""
        return self._unique_id

    @property
    def device_info(self) -> DeviceInfo:
        """Return device information."""
        return DeviceInfo(
            identifiers={(DOMAIN, self._device_id)},
            manufacturer=HYPERHDR_MANUFACTURER_NAME,
            model=HYPERHDR_MODEL_NAME,
            name=self._instance_name,
            configuration_url=self._client.remote_url,
        )

    def _get_option(self, key: str) -> Any:
        """Get a value from the provided options."""
        defaults = {
            CONF_PRIORITY: DEFAULT_PRIORITY,
            CONF_CLEAR_PRIORITY_ON_TURN_OFF: DEFAULT_CLEAR_PRIORITY_ON_TURN_OFF,
            CONF_KEEP_REALTIME_ON_TURN_OFF: DEFAULT_KEEP_REALTIME_ON_TURN_OFF,
            CONF_EFFECT_HIDE_LIST: [],
        }
        return self._options.get(key, defaults[key])

    async def _async_clear_configured_priority(self) -> bool:
        """Clear the configured HyperHDR priority slot."""
        return await self._client.async_send_clear(
            **{const.KEY_PRIORITY: self._get_option(CONF_PRIORITY)}
        )

    def _scale_rgb_to_brightness(
        self, rgb_color: Sequence[int], brightness: int
    ) -> list[int]:
        """Scale RGB to HA brightness for solid color priority."""
        if brightness >= 255:
            return list(rgb_color)
        scale = brightness / 255.0
        return [min(255, int(round(channel * scale))) for channel in rgb_color]

    def _unscale_rgb_from_brightness(
        self, rgb_color: Sequence[int], brightness: int
    ) -> tuple[int, int, int]:
        """Restore full-brightness RGB from scaled solid color priority."""
        if brightness <= 0 or brightness >= 255:
            return tuple(rgb_color)
        return tuple(
            min(255, int(round(channel * 255 / brightness))) for channel in rgb_color
        )

    async def async_turn_on(self, **kwargs: Any) -> None:
        """Turn on the light."""
        # == Get key parameters ==
        if ATTR_EFFECT not in kwargs and ATTR_HS_COLOR in kwargs:
            effect = KEY_EFFECT_SOLID
        else:
            effect = kwargs.get(ATTR_EFFECT, self._effect)
        rgb_color: Sequence[int]
        if ATTR_HS_COLOR in kwargs:
            rgb_color = color_util.color_hs_to_RGB(*kwargs[ATTR_HS_COLOR])
        else:
            rgb_color = self._rgb_color

        if ATTR_HS_COLOR in kwargs:
            self._set_internal_state(rgb_color=rgb_color)
        if ATTR_BRIGHTNESS in kwargs:
            self._set_internal_state(brightness=kwargs[ATTR_BRIGHTNESS])

        # == Set brightness ==
        if ATTR_BRIGHTNESS in kwargs:
            brightness = kwargs[ATTR_BRIGHTNESS]
            brightness_pct = int(round((float(brightness) * 100) / 255))
            luminance_gain = round(float(brightness) / 255, 3)

            # Some HyperHDR builds expose multiple adjustment entries with IDs,
            # while others only expose a single global adjustment (no ID).
            sent_any = False
            for item in self._client.adjustment or []:
                if const.KEY_ID not in item:
                    continue
                sent_any = True
                payload: dict[str, Any] = {const.KEY_ID: item[const.KEY_ID]}
                if const.KEY_BRIGHTNESS in item:
                    payload[const.KEY_BRIGHTNESS] = brightness_pct
                elif "luminanceGain" in item:
                    payload["luminanceGain"] = luminance_gain
                else:
                    # Nothing to set that maps to "brightness" on this server.
                    continue

                if not await self._client.async_send_set_adjustment(
                    **{const.KEY_ADJUSTMENT: payload}
                ):
                    return

            if not sent_any:
                global_adj: dict[str, Any] = {}
                if (
                    self._client.adjustment
                    and const.KEY_BRIGHTNESS in (self._client.adjustment[0] or {})
                ):
                    global_adj[const.KEY_BRIGHTNESS] = brightness_pct
                else:
                    global_adj["luminanceGain"] = luminance_gain

                if not await self._client.async_send_set_adjustment(
                    **{const.KEY_ADJUSTMENT: global_adj}
                ):
                    return

        # == Set an external source
        if (
            effect
            and self._support_external_effects
            and (
                effect in const.KEY_COMPONENTID_EXTERNAL_SOURCES
                or effect in const.KEY_COMPONENTID_FROM_NAME
            )
        ):
            if effect in const.KEY_COMPONENTID_FROM_NAME:
                component = const.KEY_COMPONENTID_FROM_NAME[effect]
            else:
                _LOGGER.warning(
                    "Use of HyperHDR effect '%s' is deprecated and will be removed "
                    "in a future release. Please use '%s' instead",
                    effect,
                    const.KEY_COMPONENTID_TO_NAME[effect],
                )
                component = effect

            # Clear any color/effect.
            if not await self._async_clear_configured_priority():
                return

            # Turn off all external sources, except the intended.
            available_components = {
                c.get(const.KEY_NAME)
                for c in (self._client.components or [])
                if isinstance(c, dict)
            }
            for key in const.KEY_COMPONENTID_EXTERNAL_SOURCES:
                if available_components and key not in available_components:
                    continue
                if not await self._client.async_send_set_component(
                    **{
                        const.KEY_COMPONENTSTATE: {
                            const.KEY_COMPONENT: key,
                            const.KEY_STATE: component == key,
                        }
                    }
                ):
                    return

        # == Set an effect
        elif effect and effect != KEY_EFFECT_SOLID:
            # This call should not be necessary, but without it there is no priorities-update issued:
            # https://github.com/hyperhdr-project/hyperhdr.ng/issues/992
            if not await self._async_clear_configured_priority():
                return

            if not await self._client.async_send_set_effect(
                **{
                    const.KEY_PRIORITY: self._get_option(CONF_PRIORITY),
                    const.KEY_EFFECT: {const.KEY_NAME: effect},
                    const.KEY_ORIGIN: DEFAULT_ORIGIN,
                }
            ):
                return
        # == Set a color
        else:
            effective_brightness = (
                kwargs[ATTR_BRIGHTNESS] if ATTR_BRIGHTNESS in kwargs else self._brightness
            )
            # self._rgb_color is always held at full brightness: it is set from
            # ATTR_HS_COLOR above, or restored by _update_priorities, which already
            # unscales what HyperHDR reports back. Un-scaling it a second time here
            # drove channels into the 255 clamp, shifting hue and washing colours
            # out towards white on every brightness change.
            send_color = self._scale_rgb_to_brightness(rgb_color, effective_brightness)
            if not await self._client.async_send_set_color(
                **{
                    const.KEY_PRIORITY: self._get_option(CONF_PRIORITY),
                    const.KEY_COLOR: send_color,
                    const.KEY_ORIGIN: DEFAULT_ORIGIN,
                }
            ):
                return

    def _set_internal_state(
        self,
        brightness: int | None = None,
        rgb_color: Sequence[int] | None = None,
        effect: str | None = None,
    ) -> None:
        """Set the internal state."""
        if brightness is not None:
            self._brightness = brightness
        if rgb_color is not None:
            self._rgb_color = rgb_color
        if effect is not None:
            self._effect = effect

    @callback
    def _update_components(self, _: dict[str, Any] | None = None) -> None:
        """Update HyperHDR components."""
        self.async_write_ha_state()

    @callback
    def _update_adjustment(self, _: dict[str, Any] | None = None) -> None:
        """Update HyperHDR adjustments."""
        if self._client.adjustment:
            adjustment0 = self._client.adjustment[0]
            if const.KEY_BRIGHTNESS in adjustment0:
                brightness_pct = adjustment0.get(const.KEY_BRIGHTNESS, DEFAULT_BRIGHTNESS)
                if brightness_pct < 0 or brightness_pct > 100:
                    return
                self._set_internal_state(
                    brightness=int(round((brightness_pct * 255) / float(100)))
                )
            elif "luminanceGain" in adjustment0:
                gain = adjustment0.get("luminanceGain", 1.0)
                try:
                    gain_f = float(gain)
                except (TypeError, ValueError):
                    return
                if gain_f < 0:
                    return
                self._set_internal_state(brightness=int(round(min(gain_f, 1.0) * 255)))
            self.async_write_ha_state()

    @callback
    def _update_priorities(self, _: dict[str, Any] | None = None) -> None:
        """Update HyperHDR priorities."""
        priority = self._get_priority_entry_that_dictates_state()
        if priority and self._allow_priority_update(priority):
            componentid = priority.get(const.KEY_COMPONENTID)
            if (
                self._support_external_effects
                and componentid in const.KEY_COMPONENTID_EXTERNAL_SOURCES
                and componentid in const.KEY_COMPONENTID_TO_NAME
            ):
                self._set_internal_state(
                    rgb_color=DEFAULT_COLOR,
                    effect=const.KEY_COMPONENTID_TO_NAME[componentid],
                )
            elif componentid == const.KEY_COMPONENTID_EFFECT:
                # Owner is the effect name.
                # See: https://docs.hyperhdr-project.org/en/json/ServerInfo.html#priorities
                self._set_internal_state(
                    rgb_color=DEFAULT_COLOR, effect=priority[const.KEY_OWNER]
                )
            elif componentid == const.KEY_COMPONENTID_COLOR:
                reported_rgb = priority[const.KEY_VALUE][const.KEY_RGB]
                origin = str(priority.get(const.KEY_ORIGIN, ""))
                if origin.startswith(DEFAULT_ORIGIN):
                    reported_rgb = self._unscale_rgb_from_brightness(
                        reported_rgb, self._brightness
                    )
                self._set_internal_state(
                    rgb_color=reported_rgb,
                    effect=KEY_EFFECT_SOLID,
                )
        self.async_write_ha_state()

    @callback
    def _update_effect_list(self, _: dict[str, Any] | None = None) -> None:
        """Update HyperHDR effects."""
        if not self._client.effects:
            return
        effect_list: list[str] = []
        hide_effects = self._get_option(CONF_EFFECT_HIDE_LIST)

        for effect in self._client.effects or []:
            if const.KEY_NAME in effect:
                effect_name = effect[const.KEY_NAME]
                if effect_name not in hide_effects:
                    effect_list.append(effect_name)

        self._effect_list = [
            effect for effect in self._static_effect_list if effect not in hide_effects
        ] + effect_list
        self.async_write_ha_state()

    @callback
    def _update_full_state(self) -> None:
        """Update full HyperHDR state."""
        self._update_adjustment()
        self._update_priorities()
        self._update_effect_list()

        _LOGGER.debug(
            "HyperHDR full state update: On=%s,Brightness=%i,Effect=%s "
            "(%i effects total),Color=%s",
            self.is_on,
            self._brightness,
            self._effect,
            len(self._effect_list),
            self._rgb_color,
        )

    @callback
    def _update_client(self, _: dict[str, Any] | None = None) -> None:
        """Update client connection state."""
        self.async_write_ha_state()

    async def async_added_to_hass(self) -> None:
        """Register callbacks when entity added to hass."""
        self.async_on_remove(
            async_dispatcher_connect(
                self.hass,
                SIGNAL_ENTITY_REMOVE.format(self.unique_id),
                functools.partial(self.async_remove, force_remove=True),
            )
        )

        self._client.add_callbacks(self._client_callbacks)

        # Load initial state.
        self._update_full_state()

    async def async_will_remove_from_hass(self) -> None:
        """Cleanup prior to hass removal."""
        self._client.remove_callbacks(self._client_callbacks)

    @property
    def _support_external_effects(self) -> bool:
        """Whether or not to support setting external effects from the light entity."""
        return True

    def _get_priority_entry_that_dictates_state(self) -> dict[str, Any] | None:
        """Get the relevant HyperHDR priority entry to consider."""
        # Return the visible priority (whether or not it is the HA priority).

        # Explicit type specifier to ensure this works when the underlying (typed)
        # library is installed along with the tests. Casts would trigger a
        # redundant-cast warning in this case.
        priority: dict[str, Any] | None = self._client.visible_priority
        return priority

    def _allow_priority_update(self, priority: dict[str, Any] | None = None) -> bool:
        """Determine whether to allow a priority to update internal state."""
        return True


class HyperHDRLight(HyperHDRBaseLight):
    """A HyperHDR light that acts in absolute (vs priority) manner.

    Light state is the absolute HyperHDR component state (e.g. LED device on/off) rather
    than color based at a particular priority, and the 'winning' priority determines
    shown state rather than exclusively the HA priority.
    """

    def _compute_unique_id(self, server_id: str, instance_num: int) -> str:
        """Compute a unique id for this instance."""
        return get_hyperhdr_unique_id(server_id, instance_num, TYPE_HYPERHDR_LIGHT)

    def _compute_name(self, instance_name: str) -> str:
        """Compute the name of the light."""
        return f"{instance_name} {NAME_SUFFIX_HYPERHDR_LIGHT}".strip()

    @property
    def is_on(self) -> bool:
        """Return true if light is on."""
        return (
            bool(self._client.is_on())
            and self._get_priority_entry_that_dictates_state() is not None
        )

    async def async_turn_on(self, **kwargs: Any) -> None:
        """Turn on the light."""
        # == Clear idle-black priority if set ==
        # If keep_realtime_on_turn_off was used, clear the -1 priority to restore
        # normal priority handling.
        if self._get_option(CONF_KEEP_REALTIME_ON_TURN_OFF):
            await self._client.async_send_clear(**{const.KEY_PRIORITY: -1})

        # == Turn device on ==
        # Turn on both ALL (HyperHDR itself) and LEDDEVICE. It would be
        # preferable to enable LEDDEVICE after the settings (e.g. brightness,
        # color, effect), but this is not possible due to:
        # https://github.com/hyperion-project/hyperion.ng/issues/967
        if not bool(self._client.is_on()):
            available_components = {
                c.get(const.KEY_NAME)
                for c in (self._client.components or [])
                if isinstance(c, dict)
            }
            for component in (
                const.KEY_COMPONENTID_ALL,
                const.KEY_COMPONENTID_LEDDEVICE,
            ):
                if available_components and component not in available_components:
                    continue
                if not await self._client.async_send_set_component(
                    **{
                        const.KEY_COMPONENTSTATE: {
                            const.KEY_COMPONENT: component,
                            const.KEY_STATE: True,
                        }
                    }
                ):
                    return

        # Turn on the relevant HyperHDR priority as usual.
        await super().async_turn_on(**kwargs)

    async def async_turn_off(self, **kwargs: Any) -> None:
        """Turn off the light."""
        if self._get_option(CONF_CLEAR_PRIORITY_ON_TURN_OFF):
            if not await self._async_clear_configured_priority():
                return

        if self._get_option(CONF_KEEP_REALTIME_ON_TURN_OFF):
            # Keep LED device enabled (WLED stays in realtime mode) but clear all
            # priorities to black out the output. Priority -1 is the highest priority
            # and will override all other sources.
            if not await self._client.async_send_clear(
                **{const.KEY_PRIORITY: -1}
            ):
                return
        else:
            # Default behavior: disable LED device (releases WLED from realtime mode)
            if not await self._client.async_send_set_component(
                **{
                    const.KEY_COMPONENTSTATE: {
                        const.KEY_COMPONENT: const.KEY_COMPONENTID_LEDDEVICE,
                        const.KEY_STATE: False,
                    }
                }
            ):
                return


class HyperHDRPriorityLight(HyperHDRBaseLight):
    """A HyperHDR light that only acts on a single HyperHDR priority."""

    def _compute_unique_id(self, server_id: str, instance_num: int) -> str:
        """Compute a unique id for this instance."""
        return get_hyperhdr_unique_id(
            server_id, instance_num, TYPE_HYPERHDR_PRIORITY_LIGHT
        )

    def _compute_name(self, instance_name: str) -> str:
        """Compute the name of the light."""
        return f"{instance_name} {NAME_SUFFIX_HYPERHDR_PRIORITY_LIGHT}".strip()

    @property
    def entity_registry_enabled_default(self) -> bool:
        """Whether or not the entity is enabled by default."""
        return False

    @property
    def is_on(self) -> bool:
        """Return true if light is on."""
        priority = self._get_priority_entry_that_dictates_state()
        return (
            priority is not None
            and not HyperHDRPriorityLight._is_priority_entry_black(priority)
        )

    async def async_turn_off(self, **kwargs: Any) -> None:
        """Turn off the light."""
        if not await self._async_clear_configured_priority():
            return
        await self._client.async_send_set_color(
            **{
                const.KEY_PRIORITY: self._get_option(CONF_PRIORITY),
                const.KEY_COLOR: COLOR_BLACK,
                const.KEY_ORIGIN: DEFAULT_ORIGIN,
            }
        )

    @property
    def _support_external_effects(self) -> bool:
        """Whether or not to support setting external effects from the light entity."""
        return False

    def _get_priority_entry_that_dictates_state(self) -> dict[str, Any] | None:
        """Get the relevant HyperHDR priority entry to consider."""
        # Return the active priority (if any) at the configured HA priority.
        for candidate in self._client.priorities or []:
            if const.KEY_PRIORITY not in candidate:
                continue
            if candidate[const.KEY_PRIORITY] == self._get_option(
                CONF_PRIORITY
            ) and candidate.get(const.KEY_ACTIVE, False):
                # Explicit type specifier to ensure this works when the underlying
                # (typed) library is installed along with the tests. Casts would trigger
                # a redundant-cast warning in this case.
                output: dict[str, Any] = candidate
                return output
        return None

    @classmethod
    def _is_priority_entry_black(cls, priority: dict[str, Any] | None) -> bool:
        """Determine if a given priority entry is the color black."""
        if (
            priority
            and priority.get(const.KEY_COMPONENTID) == const.KEY_COMPONENTID_COLOR
        ):
            rgb_color = priority.get(const.KEY_VALUE, {}).get(const.KEY_RGB)
            if rgb_color is not None and tuple(rgb_color) == COLOR_BLACK:
                return True
        return False

    def _allow_priority_update(self, priority: dict[str, Any] | None = None) -> bool:
        """Determine whether to allow a HyperHDR priority to update entity attributes."""
        # Black is treated as 'off' (and Home Assistant does not support selecting black
        # from the color selector). Do not set our internal attributes if the priority is
        # 'off' (i.e. if black is active). Do this to ensure it seamlessly turns back on
        # at the correct prior color on the next 'on' call.
        return not HyperHDRPriorityLight._is_priority_entry_black(priority)


LIGHT_TYPES = {
    TYPE_HYPERHDR_LIGHT: HyperHDRLight,
    TYPE_HYPERHDR_PRIORITY_LIGHT: HyperHDRPriorityLight,
}
